# C-Primer-Plus-all-codes
This repository includes all "Examples Code" in the book "C Primer Plus (6th Edition)" written by Stephen Prata, and I will write a few comments for every program. Welcome to see these beautiful codes, leave your comments, and enjoy your time!
